﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ALM.Domain
{
    public class UserStory
    {
        public string StoryNumber { get; set; }
        public string StoryDescription { get; set; }
        public string StoryOwner { get; set; }
        public string Status { get; set; }
        public string Estimation { get; set; }

        public taskDetails[] TaskDetails { get; set; }
    }

    public class taskDetails
    {
        public string TaskId { get; set; }
        public string TaskDescription { get; set; }
        public string TaskStatus { get; set; }
        public string TaskOwner { get; set; }
    }
}
