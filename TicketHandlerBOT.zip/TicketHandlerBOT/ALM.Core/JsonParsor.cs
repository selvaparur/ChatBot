﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;

namespace ALM.Core
{
    public class JsonParsor
    {
        public static JObject GetConfigurationJson()
        {
            JObject jObject = null;

            string strPath = string.Empty;

            if (AppDomain.CurrentDomain.BaseDirectory.Contains(@"bin\Debug\netcoreapp2.1\"))
            {
                strPath = AppDomain.CurrentDomain.BaseDirectory.Replace(@"bin\Debug\netcoreapp2.1\", "configuration.json");
            }
            else
            {
                strPath = AppDomain.CurrentDomain.BaseDirectory + "configuration.json";
            }

            using (StreamReader file = File.OpenText(strPath))
            using (JsonTextReader jreader = new JsonTextReader(file))
            {
                jObject = (JObject)JToken.ReadFrom(jreader);
            }

            return jObject;
        }
    }
}
