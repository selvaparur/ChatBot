﻿using System;

namespace ALM.Core
{
    public class Class1
    {
    }
}
