﻿using System;

namespace ALM.IntentProcessor
{
    public class Class1
    {
        public void test()
        {
            
        }
    }
}
